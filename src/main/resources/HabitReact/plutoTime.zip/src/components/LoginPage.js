/* eslint-disable */

import React from 'react';
import './LoginPage.scss';
import Logo from './Logo.svg';
import Constants from './constants';

const API = Constants.API;

class LoginPage extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			username: '',
			password: ''
		};
	}

	login = () => {
		const url = `${API}/validate`;
		fetch(url, {
      method: 'POST',
      body: JSON.stringify({
      	username: this.state.username,
      	password: this.state.password
      }),
      headers: {
	      'Content-Type': 'application/json'
	    }
    })
      .then((response) => response.json())
      .then((response) => {
        this.props.history.push("/maps", { userId: response.userId })
      })
      .catch((err) => {
        console.log('error getting user list', err);
      });
	}

	render() {
		const { history } = this.props;
		return (
			<div className="loginPage">
				<div className="logo">
					<object data={Logo} type="image/svg+xml" />
				</div>
				<input
					placeholder="Username"
					onChange={(event) => {this.setState({ username: event.target.value }); }}
					value={this.state.username}
					className="loginField"
					type="text"
				/>
				<input
					placeholder="Password"
					onChange={(event) => {this.setState({ password: event.target.value }); }}
					value={this.state.password}
					className="loginField"
					type="password"
				/>
				<button onClick={this.login} className="loginBtn">
					Login
				</button>
			</div>
		);
	}
};

export default LoginPage;
