/* eslint-disable */

export default {
	API: "http://ec2-52-10-235-171.us-west-2.compute.amazonaws.com"
};

// let API = "http://c02x19lwjg5j:8080";
// API = "http://ec2-52-10-235-171.us-west-2.compute.amazonaws.com";