/* eslint-disable */

import React from 'react';
import ProfileImg from './ProfilePage.png';

class ProfilePage extends React.Component {
  render() {
    return (
      <div className="profile-page">
        <img src={ProfileImg} />
        <button style={{}}>Log out</button>
        <div style={{ top: '-110px', position: 'relative' }}>
	        <button className="ProfileDisabled btn" onClick={() => { this.props.history.push('/login'); }}>
	        </button>
	        <button className="DiscoverDisabled btn" onClick={() => { this.props.history.push('/myProfile'); }}></button>
	        <button className="ProfileDisabled btn" onClick={() => { this.props.history.push('/maps'); }}></button>
	      </div>
      </div>
    );
  }
};

export default ProfilePage;
