/* eslint-disable */

import React from 'react';

class Discovery extends React.Component {
  render() {
    return (
      <div>
        <div></div>
      </div>
    );
  }
};

export default Discovery;
