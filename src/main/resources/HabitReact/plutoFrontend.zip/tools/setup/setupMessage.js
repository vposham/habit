// This script displays an intro message for the setup script
/* eslint-disable no-console */
console.log('===========================');
console.log('=  React Slingshot Setup  =');
console.log('===========================\n');
console.log('Installing dependencies. Please wait...');
