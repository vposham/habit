/* eslint-disable */
import React, { Component } from 'react';
import {
  Map,
  GoogleApiWrapper,
  InfoWindow,
  Marker
} from 'google-maps-react';
import uuidv4 from 'uuid/v4';
import './HomePage.scss';
import Placeholder from './placeholder.svg';
import Add from './Add.svg';
import Stop from './Stop.svg';
import Play from './Play.svg';

let API = "http://c02x19lwjg5j:8080";
API = "http://ec2-52-10-235-171.us-west-2.compute.amazonaws.com";
// /admin/user

const mapStyles = {
  width: '375px',
  height: '667px'
};

// const users = [
//    {
//       "userId":"5d992d8bb83474000180aca7",
//       "username":"dilip1",
//       "password":"Tester123",
//       "isPrivate":false,
//       "private":false
//    },
//    {
//       "userId":"5d992d8bb83474000180aca8",
//       "username":"sachin1",
//       "password":"Tester123",
//       "isPrivate":false,
//       "private":false
//    },
//    {
//       "userId":"5d992d8bb83474000180aca9",
//       "username":"praveen1",
//       "password":"Tester123",
//       "isPrivate":false,
//       "private":false
//    },
//    {
//       "userId":"5d992d8bb83474000180acaa",
//       "username":"mihai1",
//       "password":"Tester123",
//       "isPrivate":false,
//       "private":false
//    },
//    {
//       "userId":"5d992d8bb83474000180acab",
//       "username":"posham1",
//       "password":"Tester123",
//       "isPrivate":false,
//       "private":false
//    },
//    {
//       "userId":"5d992d8bb83474000180acac",
//       "username":"norman1",
//       "password":"Tester123",
//       "isPrivate":false,
//       "private":false
//    },
//    {
//       "userId":"5d992d8bb83474000180acad",
//       "username":"dilip2",
//       "password":"Tester123",
//       "isPrivate":true,
//       "private":true
//    },
//    {
//       "userId":"5d992d8bb83474000180acae",
//       "username":"sachin2",
//       "password":"Tester123",
//       "isPrivate":true,
//       "private":true
//    },
//    {
//       "userId":"5d992d8bb83474000180acaf",
//       "username":"praveen2",
//       "password":"Tester123",
//       "isPrivate":true,
//       "private":true
//    },
//    {
//       "userId":"5d992d8bb83474000180acb0",
//       "username":"mihai2",
//       "password":"Tester123",
//       "isPrivate":true,
//       "private":true
//    },
//    {
//       "userId":"5d992d8bb83474000180acb1",
//       "username":"posham2",
//       "password":"Tester123",
//       "isPrivate":true,
//       "private":true
//    },
//    {
//       "userId":"5d992d8bb83474000180acb2",
//       "username":"norman2",
//       "password":"Tester123",
//       "isPrivate":true,
//       "private":true
//    }
// ];

const coords = { lat: -21.805149, lng: -49.0921657 };
// console.log('coords are', coords);



// console.log('sttart recognition');
// recognition.start();

const USERS = {

};

export class HomePage extends Component {
  constructor(props) {
    super(props);
    // console.log('props are', props);
    this.audioBlob = null;
    this.state = {
      user: 'sachin1',
      showingInfoWindow: false,
      activeMarker: {},
      selectedPlace: {},
      showMarkerDetails: null,
      newMarkerInProgress: null,
      newMarkerInProgressId: null,
      markers: [
        
      ],
      userList: null,
      showTimer: false
    };
  }

  getUserIdByUsername = (loggedUsername) => {
    if (this.state.userList) {
      let userid = null;
      Object.keys(this.state.userList).forEach((key) => {
        const user = this.state.userList[key];
        if (user.username === loggedUsername) {
          userid = user.userId
        }
      });
      return userid;
    }
    return null;
  };

  setupSpeechRecognition = () => {
    try {
      var SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      this.recognition = new SpeechRecognition();
    } catch (err) {
      console.log('speech recognition error', err);
    }
    console.log('setting up recognition');
    this.recognition.continuous = true;
    this.recognition.onresult = (event) => {
      // event is a SpeechRecognitionEvent object.
      // It holds all the lines we have captured so far. 
      // We only need the current one.
      var current = event.resultIndex;
      // Get a transcript of what was said.
      var transcript = event.results[current][0].transcript;
      console.log('RECOGNITION on result..', transcript);

      // Add the current transcript to the contents of our Note.
      // There is a weird bug on mobile, where everything is repeated twice.
      // There is no official solution so far so we have to handle an edge case.
      var mobileRepeatBug = (current == 1 && transcript == event.results[0][0].transcript);
      const { newMarkerInProgress, markers, newMarkerInProgressId } = this.state;

      markers.forEach((marker) => {
        if (marker.id === newMarkerInProgressId) {
          marker.transcript = transcript;
        }
      });
      this.setState({
        newMarkerInProgress: null
      });
      // if(!mobileRepeatBug) {
      //   noteContent += transcript;
      //   noteTextarea.val(noteContent);
      // }
    };
    this.recognition.onstart = () => {
      console.log('onstart..');
    }

    this.recognition.onspeechend = () => {
      console.log('onspeechend..');
      const { newMarkerInProgress } = this.state;
      if (newMarkerInProgress !== null) {
        this.setState({
          newMarkerInProgress: null
        });
      }
    }

    this.recognition.onerror = function(event) {
      console.log('onerror', event);
    }
  };

  componentWillMount = () => {
    // console.log('comp will mount.');
    this.setupSpeechRecognition();
    this.loadUsers();
  }

  loadUsers = () => {
    const url = `${API}/admin/user`;
    console.log('loadusers url is', url);
    fetch(url, {
      method: 'GET'
    })
      .then((response) => response.json())
      .then((response) => {
        console.log('response is..', response);
        this.setState({
          userList: response
        });
        console.log('get user it..', );
        this.loadPins(this.getUserIdByUsername(this.state.user));
      })
      .catch((err) => {
        console.log('error getting user list', err);
      });
  };

  loadPins = (userid) => {
    const lat = 26.35869;
    const long = -80.0831;
    const url = `http://ec2-52-10-235-171.us-west-2.compute.amazonaws.com/${userid}/geo?latitude=${lat.toString()}&longitude=${long.toString()}`;
    console.log('url is', url);
    fetch(url, {
      method: 'GET'
    })
      .then(function(response) {
          if (response.status >= 400) {
            throw new Error("Bad response from server");
          }
          return response.json();
      })
      .then(function(data) {
          console.log('-----> response from server is', data);
      })
      .catch((err) => {
        console.log('-----> error uploading pin to server');
      })
  };

  stopRecording = () => {
    clearInterval(this.myTimer);
    this.myTimer = null;
    this.setState({
      showTimer: false
    });
    this.currentSeconds = 0;
    this.mediaRecorder.stop();
  };

  startTimer = () => {
    this.currentSeconds = 0;
    this.myTimer = setInterval(() => {
      const el = document.getElementById('time');
      el.innerHTML = this.currentSeconds < 10 ?
        "0:0".concat(this.currentSeconds) : "0:".concat(this.currentSeconds);
      this.currentSeconds++;
    }, 1000);
  };

  startRecording = (pinId) => {
    console.log('starting recognition', this.recognition);
    this.setState({
      showTimer: true
    });
    this.startTimer();
    this.recognition.start();
    // console.log('start recording..', window.navigator);
    window.navigator.mediaDevices.getUserMedia({ audio: true })
      .then(stream => {
        // console.log('hello media recordder...');
        const mediaRecorder = new MediaRecorder(stream);
        this.mediaRecorder = mediaRecorder;
        this.mediaRecorder.start();

        this.audioChunks = [];
        this.mediaRecorder.addEventListener("dataavailable", event => {
          // console.log('recording.....');
          this.audioChunks.push(event.data);
        });

        mediaRecorder.addEventListener("stop", () => {
          const audioBlob = new Blob(this.audioChunks);
          this.audioBlob = audioBlob;
          const audioUrl = URL.createObjectURL(audioBlob);
          const audio = new Audio(audioUrl);
          this.audio = audio;
          this.audio.play();

          console.log('stopped recording.. now adding the audio information to the marker');
          const {
            markers,
            newMarkerInProgress,
            newMarkerInProgressId
          } = this.state;
          markers.forEach((marker) => {
            if (marker.id === newMarkerInProgressId) {
              marker.audioBlob = this.audioBlob;
            }
          });

          this.setState({
            newMarkerInProgress: {
              ...this.state.newMarkerInProgress,
              audioBlob: this.audioBlob
            }
          }, () => {
            this.recognition.stop();
          });

          this.audioBlob = null;
          this.audio = null;
          this.audioChunks = null;
        });

        // setTimeout(() => {
        //   this.mediaRecorder.stop();
        // }, 3000);
      });
  };

  onMarkerClick = (props, marker, e) => {
    this.setState({
      selectedPlace: props,
      activeMarker: marker,
      showingInfoWindow: true
    });
  };

  clickMarker = (marker) => {
    this.setState({
      showMarkerDetails: marker
    });
    if (marker && marker.audioBlob){
      const audioUrl = URL.createObjectURL(marker.audioBlob);
      const audio = new Audio(audioUrl);
      audio.play();
    }
  };

  onClose = props => {
    if (this.state.showingInfoWindow) {
      this.setState({
        showingInfoWindow: false,
        activeMarker: null
      });
    }
  };

  getMyLocation() {
    const location = window.navigator && window.navigator.geolocation;
    if (location) {
      console.log('getting current location', location);
      location.getCurrentPosition((position) => {
        this.setState({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
        })
      }, (error) => {
        console.log('error location', error);
        // this.setState({ latitude: 'err-latitude', longitude: 'err-longitude' })
      })
    }
  }

  createPinAtCenter = () => {
    console.log('get map coordinates...', this.props);
  }
  // getMyLocation = (e) => {
  //   let location = null;
  //   let latitude = null;
  //   let longitude = null;
  //   if (window.navigator && window.navigator.geolocation) {
  //       location = window.navigator.geolocation;
  //   }
  //   if (location){
  //       location.getCurrentPosition(function (position) {
  //           latitude = position.coords.latitude;
  //           longitude= position.coords.longitude;
  //           console.log('latitude', latitude);
  //           console.log('longitude', longitude);
  //       })
  //   }
  //   this.setState({latitude: latitude, longitude: longitude})
  // }

  mapClicked = (mapProps, map, event) => {
    // console.log('map clicked..', event);
    const lat = event.latLng.lat();
    const lng = event.latLng.lng();
    console.log('lat lng', lat, lng);
    const { markers } = this.state;



    // this.setState({
    //   markers,
    //   newMarkerInProgress: {
    //     position: {
    //       lat,
    //       lng
    //     }
    //   }
    // });
  };

  createPinClick = () => {
    // console.log('map clicked..', event);
    // const lat = event.latLng.lat();
    // const lng = event.latLng.lng();

    const lat = 26.354113939825073;
    const lng = -80.07743517456055;
    const { markers } = this.state;
    const pinId = uuidv4();
    const newPin = {
      name: 'test',
      id: pinId,
      position: {
        lat,
        lng
      }
    };
    markers.push(newPin);
    this.setState({
      markers,
      newMarkerInProgressId: pinId,
      newMarkerInProgress: {
        ...newPin
      }
    });

    this.startRecording(pinId);
  };

  closeShowMarkerDetails = () => {
    this.setState({
      showMarkerDetails: null
    });
  };

  saveNewPin = () => {
    let {
      newMarkerInProgress,
      markers
    } = this.state;

    const newPin = {
      ...newMarkerInProgress,
      name: "Current position",
      position: {
        lat: newMarkerInProgress.position.lat,
        lng: newMarkerInProgress.position.lng
      },
      audioBlob: newMarkerInProgress.audioBlob,
      transcript: newMarkerInProgress.transcript
    };

    // console.log('UPLOAD THIS PIN.', newMarkerInProgress);
    const formData = new FormData();
    formData.append('file', newMarkerInProgress.audioBlob);
    formData.append('name', name);
    formData.append('lat', newMarkerInProgress.position.lat);
    formData.append('lng', newMarkerInProgress.position.lng);
    formData.append('transcript', newMarkerInProgress.transcript);

    const url = "https://dev.odplabs...";

    // fetch(url, {
    //   method: 'POST',
    //   body: form
    // })
    //   .then(function(response) {
    //       if (response.status >= 400) {
    //         throw new Error("Bad response from server");
    //       }
    //       return response.json();
    //   })
    //   .then(function(data) {
    //       console.log('response from server is', data);
    //   })
    //   .catch((err) => {
    //     console.log('error uploading pin to server');
    //   })

    // after server success response...
    markers.push(newPin);

    this.setState({
      markers,
      newMarkerInProgress: null
    });
  };

  cancelNewPin = () => {
    this.setState({
      newMarkerInProgress: null
    });
  };

  render() {
    const {
      newMarkerInProgress,
      showMarkerDetails,
      markers,
      showTimer
    } = this.state;
    console.log('Markers is', markers);

    return (
      <div>
        <button onClick={() => { this.setState({ user: 'mihai1' })} }>Login as mihai1</button>
        <button onClick={() => { this.setState({ user: 'dilip1' })} }>Login as dilip1</button>
        <button onClick={() => { this.setState({ user: 'sachin1' })} }>Login as sachin1</button>
        <button onClick={() => { this.setState({ user: 'praveen1' })} }>Login as praveen1</button>
        <button onClick={() => { this.setState({ user: 'posham1' })} }>Login as posham1</button>
        <button onClick={() => { this.setState({ user: 'norman1' })} }>Login as norman1</button>
        <button onClick={() => { this.setState({ user: 'dilip2' })} }>Login as dilip2</button>
        <button onClick={() => { this.setState({ user: 'sachin2' })} }>Login as sachin2</button>
        <button onClick={() => { this.setState({ user: 'praveen2' })} }>Login as praveen2</button>
        <button onClick={() => { this.setState({ user: 'mihai2' })} }>Login as mihai2</button>
        <button onClick={() => { this.setState({ user: 'posham2' })} }>Login as posham2</button>
        <button onClick={() => { this.setState({ user: 'norman2' })} }>Login as norman2</button>
        <br />
      <button onClick={this.startRecording}>record</button>
      
      <button onClick={this.getMyLocation}>get my location</button>
      <button onClick={this.createPinAtCenter}>create pin at center of map</button>
        { newMarkerInProgress ? (
          <div>
            Add new ..
            <input type="text" />
            <button onClick={this.saveNewPin}>Save</button>
            <button onClick={this.cancelNewPin}>Cancel</button>
            <button onClick={this.startRecording}>record</button>
            <button onClick={this.stopRecording}>stop</button>
          </div>
        ) : null }

        
        <div id="mapContainer">
          <Map
            google={this.props.google}
            zoom={14}
            style={mapStyles}
            initialCenter={{
             lat: 26.35869,
             lng: -80.0831
            }}
            streetViewControl={false}
            fullscreenControl={false}
            zoomControl={false}
            mapTypeControl={false}
            onClick={this.mapClicked}
          >
            {this.state.markers.map((marker, index) => (
              <Marker
                key={index}
                position={marker.position}
                onClick={() => { this.clickMarker(marker); }}
                draggable={true}
                onDragend={(t, map, coord) => this.onMarkerDragEnd(coord, index)}
                name={marker.name}
              />
            ))}
          </Map>
          <button
            className={() => {
              if (showMarkerDetails) {
                return 'Play';
              }
              if (newMarkerInProgress) {
                return 'Stop';
              }
              return 'Add'
            }}
            onClick={newMarkerInProgress ? this.stopRecording : this.createPinClick}
            id="getCurrentPosition"
          >
          </button>
          { showTimer ? (
            <div id="newMarkerInfo">
              <p id="time"></p>
            </div>
          ) : null
          }
            
          
          { showMarkerDetails ? (
            <div id="detailedMarkerInfo">
              <p className="detailedViewName">{this.state.user}</p>
              { showMarkerDetails.transcript ?
                <p className="detailedViewName detailedViewName-transcript">{ showMarkerDetails.transcript }</p> : null
              }

              {/* <button className="closeDetailedView" onClick={this.closeShowMarkerDetails}>x</button> */}
            </div>
            ) : null
          }
        </div>
        

      </div>
    );
  }
}

export default GoogleApiWrapper({
  apiKey: 'AIzaSyCr4Pn99v4-h3R4UP0LuFGqS2IxBUafuiE'
})(HomePage);