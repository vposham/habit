/* eslint-disable */
import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { ConnectedRouter } from 'connected-react-router';
import { Provider } from 'react-redux';
import HomePage from './HomePage';

export default class Root extends Component {
  render() {
    const { store, history } = this.props;
    return (
        <HomePage />
    );
  }
}

Root.propTypes = {
  store: PropTypes.object.isRequired,
  history: PropTypes.object.isRequired
};
